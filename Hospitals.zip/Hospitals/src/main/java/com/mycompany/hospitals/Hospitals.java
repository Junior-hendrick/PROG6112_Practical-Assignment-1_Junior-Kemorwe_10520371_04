/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hospitals;

/**
 *
 * @author Student
 */
public class Hospitals {

    public static void main(String[] args) {
         HospitalSystem system =
                new HospitalSystem();

        system.start();
    }
}
