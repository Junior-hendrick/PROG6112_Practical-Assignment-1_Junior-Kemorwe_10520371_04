/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitals;
import java.util.ArrayList;
import java.util.Comparator;
public class PatientManager {
    private ArrayList<Patient> patients;

    public PatientManager() {
        patients = new ArrayList<>();
    }

    public boolean registerPatient(Patient patient) {

        if (patient == null) {
            throw new IllegalArgumentException("Patient cannot be null.");
        }

        if (searchPatient(patient.getPatientId()) != null) {
            return false;
        }

        patients.add(patient);
        return true;
    }

    public Patient searchPatient(String patientId) {

        for (Patient patient : patients) {

            if (patient.getPatientId().equalsIgnoreCase(patientId)) {
                return patient;
            }
        }

        return null;
    }

    public boolean updatePatient(String patientId,
                                 String firstName,
                                 String lastName,
                                 int age,
                                 String gender,
                                 String medicalCondition,
                                 PatientCategory category) {

        Patient patient = searchPatient(patientId);

        if (patient == null) {
            return false;
        }

        patient.setFirstName(firstName);
        patient.setLastName(lastName);
        patient.setAge(age);
        patient.setGender(gender);
        patient.setMedicalCondition(medicalCondition);
        patient.setCategory(category);

        return true;
    }

    public boolean deletePatient(String patientId) {

        Patient patient = searchPatient(patientId);

        if (patient == null) {
            return false;
        }

        patients.remove(patient);
        return true;
    }

    public void displayAllPatients() {

        if (patients.isEmpty()) {
            System.out.println("No patients registered.");
            return;
        }

        for (Patient patient : patients) {
            System.out.println("-------------------------");
            patient.displayDetails();
        }
    }

    public int getPatientCount() {
        return patients.size();
    }

    public ArrayList<Patient> getPatients() {
        return patients;
    }

    // Sort by surname

    public void sortBySurname() {

        patients.sort(Comparator.comparing(
                Patient::getLastName,
                String.CASE_INSENSITIVE_ORDER
        ));
    }

    // Sort by patient ID

    public void sortByPatientId() {

        patients.sort(Comparator.comparing(
                Patient::getPatientId,
                String.CASE_INSENSITIVE_ORDER
        ));
    }

    // Convert ArrayList to array

    public Patient[] getPatientArray() {

        return patients.toArray(new Patient[0]);
    }

    // Method that accepts an array as a parameter

    public static void displayPatientArray(Patient[] patientArray) {

        System.out.println("Total patients in array: "
                + patientArray.length);

        for (int i = 0; i < patientArray.length; i++) {
            System.out.println("-------------------------");
            patientArray[i].displayDetails();
        }
    }
}
