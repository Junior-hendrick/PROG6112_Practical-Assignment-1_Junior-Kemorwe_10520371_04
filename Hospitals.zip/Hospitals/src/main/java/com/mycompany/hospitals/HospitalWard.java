/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitals;
import java.util.ArrayList;
public class HospitalWard {
    private static final int ROWS = 4;
    private static final int COLUMNS = 5;

    private String[][] beds;
    private Inpatient[][] patientsInBeds;

    public HospitalWard() {

        beds = new String[ROWS][COLUMNS];
        patientsInBeds = new Inpatient[ROWS][COLUMNS];

        initialiseBeds();
    }

    private void initialiseBeds() {

        int bedNumber = 1;

        for (int row = 0; row < ROWS; row++) {

            for (int column = 0; column < COLUMNS; column++) {

                beds[row][column] =
                        String.format("B%02d", bedNumber);

                patientsInBeds[row][column] = null;

                bedNumber++;
            }
        }
    }

    public boolean allocateBed(Inpatient patient, String bedNumber) {

        if (patient == null) {
            throw new IllegalArgumentException(
                    "Patient cannot be null."
            );
        }

        if (findPatientBed(patient.getPatientId()) != null) {
            return false;
        }

        for (int row = 0; row < ROWS; row++) {

            for (int column = 0; column < COLUMNS; column++) {

                if (beds[row][column].equalsIgnoreCase(bedNumber)) {

                    if (patientsInBeds[row][column] != null) {
                        return false;
                    }

                    patientsInBeds[row][column] = patient;

                    patient.setBedNumber(
                            beds[row][column]
                    );

                    return true;
                }
            }
        }

        return false;
    }

    public boolean releaseBed(String bedNumber) {

        for (int row = 0; row < ROWS; row++) {

            for (int column = 0; column < COLUMNS; column++) {

                if (beds[row][column].equalsIgnoreCase(bedNumber)) {

                    if (patientsInBeds[row][column] == null) {
                        return false;
                    }

                    patientsInBeds[row][column].setBedNumber("None");

                    patientsInBeds[row][column] = null;

                    return true;
                }
            }
        }

        return false;
    }

    public Inpatient findPatientBed(String patientId) {

        for (int row = 0; row < ROWS; row++) {

            for (int column = 0; column < COLUMNS; column++) {

                Inpatient patient =
                        patientsInBeds[row][column];

                if (patient != null &&
                        patient.getPatientId()
                                .equalsIgnoreCase(patientId)) {

                    return patient;
                }
            }
        }

        return null;
    }

    public void displayWardLayout() {

        System.out.println("\nWARD LAYOUT");
        System.out.println("----------------------------");

        for (int row = 0; row < ROWS; row++) {

            for (int column = 0; column < COLUMNS; column++) {

                if (patientsInBeds[row][column] == null) {

                    System.out.print(
                            "[" + beds[row][column] + " Available] "
                    );

                } else {

                    System.out.print(
                            "[" + beds[row][column] + " Occupied] "
                    );
                }
            }

            System.out.println();
        }
    }

    public void displayAvailableBeds() {

        System.out.println("\nAVAILABLE BEDS");

        boolean found = false;

        for (int row = 0; row < ROWS; row++) {

            for (int column = 0; column < COLUMNS; column++) {

                if (patientsInBeds[row][column] == null) {

                    System.out.print(
                            beds[row][column] + " "
                    );

                    found = true;
                }
            }
        }

        if (!found) {
            System.out.println("No available beds.");
        }

        System.out.println();
    }

    public void displayOccupiedBeds() {

        System.out.println("\nOCCUPIED BEDS");

        boolean found = false;

        for (int row = 0; row < ROWS; row++) {

            for (int column = 0; column < COLUMNS; column++) {

                if (patientsInBeds[row][column] != null) {

                    System.out.println(
                            beds[row][column]
                                    + " - "
                                    + patientsInBeds[row][column]
                                    .getFirstName()
                                    + " "
                                    + patientsInBeds[row][column]
                                    .getLastName()
                    );

                    found = true;
                }
            }
        }

        if (!found) {
            System.out.println("No occupied beds.");
        }
    }

    public int getOccupiedBedCount() {

        int count = 0;

        for (int row = 0; row < ROWS; row++) {

            for (int column = 0; column < COLUMNS; column++) {

                if (patientsInBeds[row][column] != null) {
                    count++;
                }
            }
        }

        return count;
    }

    public int getAvailableBedCount() {
        return 20 - getOccupiedBedCount();
    }

    public double getOccupancyPercentage() {

        return (getOccupiedBedCount() / 20.0) * 100;
    }

    public boolean areAllBedsOccupied() {
        return getOccupiedBedCount() == 20;
    }

    // Demonstrates a three-dimensional array

    public void demonstrateThreeDimensionalArray() {

        String[][][] wardData = new String[1][ROWS][COLUMNS];

        for (int ward = 0; ward < wardData.length; ward++) {

            for (int row = 0; row < wardData[ward].length; row++) {

                for (int column = 0;
                     column < wardData[ward][row].length;
                     column++) {

                    wardData[ward][row][column] =
                            beds[row][column];
                }
            }
        }

        System.out.println(
                "3D ward array created successfully."
        );
    }
}
