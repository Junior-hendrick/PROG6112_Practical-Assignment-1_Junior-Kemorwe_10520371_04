/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitals;
import java.util.Scanner;
public class HospitalSystem {
     private PatientManager patientManager;
    private HospitalWard ward;
    private Scanner scanner;

    public HospitalSystem() {

        patientManager = new PatientManager();
        ward = new HospitalWard();
        scanner = new Scanner(System.in);
    }

    public void start() {

        boolean running = true;

        while (running) {

            displayMainMenu();

            try {

                int choice = Integer.parseInt(
                        scanner.nextLine()
                );

                switch (choice) {

                    case 1:
                        registerPatient();
                        break;

                    case 2:
                        searchPatient();
                        break;

                    case 3:
                        updatePatient();
                        break;

                    case 4:
                        deletePatient();
                        break;

                    case 5:
                        patientManager.displayAllPatients();
                        break;

                    case 6:
                        allocateBed();
                        break;

                    case 7:
                        releaseBed();
                        break;

                    case 8:
                        ward.displayWardLayout();
                        break;

                    case 9:
                        ward.displayAvailableBeds();
                        break;

                    case 10:
                        ward.displayOccupiedBeds();
                        break;

                    case 11:
                        displayReport();
                        break;

                    case 12:
                        patientManager.sortBySurname();
                        System.out.println(
                                "Patients sorted by surname."
                        );
                        patientManager.displayAllPatients();
                        break;

                    case 13:
                        patientManager.sortByPatientId();
                        System.out.println(
                                "Patients sorted by patient ID."
                        );
                        patientManager.displayAllPatients();
                        break;

                    case 14:
                        ward.demonstrateThreeDimensionalArray();
                        break;

                    case 0:
                        running = false;
                        System.out.println(
                                "Thank you for using Medicare Hospital System."
                        );
                        break;

                    default:
                        System.out.println(
                                "Invalid menu option."
                        );
                }

            } catch (NumberFormatException e) {

                System.out.println(
                        "Please enter a valid number."
                );

            } catch (Exception e) {

                System.out.println(
                        "Error: " + e.getMessage()
                );
            }
        }
    }

    private void displayMainMenu() {

        System.out.println("\n================================");
        System.out.println(" MEDICARE HOSPITAL SYSTEM");
        System.out.println("================================");

        System.out.println("1. Register new patient");
        System.out.println("2. Search for patient");
        System.out.println("3. Update patient");
        System.out.println("4. Delete patient");
        System.out.println("5. Display all patients");
        System.out.println("6. Allocate bed");
        System.out.println("7. Release bed");
        System.out.println("8. Display ward layout");
        System.out.println("9. Display available beds");
        System.out.println("10. Display occupied beds");
        System.out.println("11. Generate ward report");
        System.out.println("12. Sort patients by surname");
        System.out.println("13. Sort patients by patient ID");
        System.out.println("14. Demonstrate 3D array");
        System.out.println("0. Exit");
        System.out.print("Enter your choice: ");
    }

    private void registerPatient() {

        System.out.println("\nREGISTER PATIENT");

        System.out.print("Patient ID: ");
        String id = scanner.nextLine();

        if (patientManager.searchPatient(id) != null) {

            System.out.println(
                    "Patient ID already exists."
            );

            return;
        }

        System.out.print("First name: ");
        String firstName = scanner.nextLine();

        System.out.print("Last name: ");
        String lastName = scanner.nextLine();

        int age = readInteger("Age: ");

        System.out.print("Gender: ");
        String gender = scanner.nextLine();

        System.out.print("Medical condition: ");
        String condition = scanner.nextLine();

        PatientCategory category =
                readCategory();

        Patient patient;

        if (category == PatientCategory.INPATIENT) {

            System.out.print("Ward number: ");
            String wardNumber = scanner.nextLine();

            patient = new Inpatient(
                    id,
                    firstName,
                    lastName,
                    age,
                    gender,
                    condition,
                    wardNumber,
                    "None"
            );

        } else {

            patient = new Patient(
                    id,
                    firstName,
                    lastName,
                    age,
                    gender,
                    condition,
                    category
            );
        }

        if (patientManager.registerPatient(patient)) {

            System.out.println(
                    "Patient successfully registered."
            );

        } else {

            System.out.println(
                    "Patient could not be registered."
            );
        }
    }

    private void searchPatient() {

        System.out.print("Enter patient ID: ");

        String id = scanner.nextLine();

        Patient patient =
                patientManager.searchPatient(id);

        if (patient == null) {

            System.out.println(
                    "Patient not found."
            );

        } else {

            System.out.println("\nPATIENT FOUND");
            patient.displayDetails();
        }
    }

    private void updatePatient() {

        System.out.print("Enter patient ID to update: ");

        String id = scanner.nextLine();

        Patient patient =
                patientManager.searchPatient(id);

        if (patient == null) {

            System.out.println(
                    "Patient not found."
            );

            return;
        }

        System.out.print("New first name: ");
        String firstName = scanner.nextLine();

        System.out.print("New last name: ");
        String lastName = scanner.nextLine();

        int age = readInteger("New age: ");

        System.out.print("New gender: ");
        String gender = scanner.nextLine();

        System.out.print("New medical condition: ");
        String condition = scanner.nextLine();

        PatientCategory category =
                readCategory();

        boolean updated =
                patientManager.updatePatient(
                        id,
                        firstName,
                        lastName,
                        age,
                        gender,
                        condition,
                        category
                );

        if (updated) {

            System.out.println(
                    "Patient successfully updated."
            );

        } else {

            System.out.println(
                    "Patient could not be updated."
            );
        }
    }

    private void deletePatient() {

        System.out.print("Enter patient ID to delete: ");

        String id = scanner.nextLine();

        Patient patient =
                patientManager.searchPatient(id);

        if (patient == null) {

            System.out.println(
                    "Patient not found."
            );

            return;
        }

        if (patient instanceof Inpatient) {

            Inpatient inpatient =
                    (Inpatient) patient;

            if (!inpatient.getBedNumber().equals("None")) {

                System.out.println(
                        "Cannot delete an inpatient while a bed is allocated."
                );

                return;
            }
        }

        if (patientManager.deletePatient(id)) {

            System.out.println(
                    "Patient successfully deleted."
            );

        } else {

            System.out.println(
                    "Patient could not be deleted."
            );
        }
    }

    private void allocateBed() {

        System.out.print("Enter inpatient patient ID: ");

        String id = scanner.nextLine();

        Patient patient =
                patientManager.searchPatient(id);

        if (patient == null) {

            System.out.println(
                    "Patient not found."
            );

            return;
        }

        if (!(patient instanceof Inpatient)) {

            System.out.println(
                    "Only inpatients may be allocated beds."
            );

            return;
        }

        if (ward.areAllBedsOccupied()) {

            System.out.println(
                    "All 20 beds are occupied."
            );

            return;
        }

        Inpatient inpatient =
                (Inpatient) patient;

        System.out.print("Enter bed number, e.g. B01: ");

        String bedNumber = scanner.nextLine();

        if (ward.allocateBed(inpatient, bedNumber)) {

            System.out.println(
                    "Bed successfully allocated."
            );

        } else {

            System.out.println(
                    "Bed is occupied, invalid, or patient already has a bed."
            );
        }
    }

    private void releaseBed() {

        System.out.print("Enter bed number: ");

        String bedNumber = scanner.nextLine();

        if (ward.releaseBed(bedNumber)) {

            System.out.println(
                    "Bed successfully released."
            );

        } else {

            System.out.println(
                    "Bed is invalid or already available."
            );
        }
    }

    private void displayReport() {

        System.out.println("\n================================");
        System.out.println(" MEDICARE WARD REPORT");
        System.out.println("================================");

        System.out.println(
                "Total registered patients: "
                        + patientManager.getPatientCount()
        );

        System.out.println(
                "Total occupied beds: "
                        + ward.getOccupiedBedCount()
        );

        System.out.println(
                "Total available beds: "
                        + ward.getAvailableBedCount()
        );

        System.out.println(
                "Ward occupancy: "
                        + ward.getOccupancyPercentage()
                        + "%"
        );

        ward.displayAvailableBeds();
        ward.displayOccupiedBeds();
    }

    private PatientCategory readCategory() {

        while (true) {

            System.out.println("\nPatient Category");

            System.out.println("1. Inpatient");
            System.out.println("2. Outpatient");
            System.out.println("3. Emergency");

            System.out.print("Choose category: ");

            try {

                int choice =
                        Integer.parseInt(scanner.nextLine());

                switch (choice) {

                    case 1:
                        return PatientCategory.INPATIENT;

                    case 2:
                        return PatientCategory.OUTPATIENT;

                    case 3:
                        return PatientCategory.EMERGENCY;

                    default:
                        System.out.println(
                                "Invalid category."
                        );
                }

            } catch (NumberFormatException e) {

                System.out.println(
                        "Please enter a number."
                );
            }
        }
    }

    private int readInteger(String message) {

        while (true) {

            System.out.print(message);

            try {

                int number =
                        Integer.parseInt(scanner.nextLine());

                if (number < 0) {

                    System.out.println(
                            "Number cannot be negative."
                    );

                    continue;
                }

                return number;

            } catch (NumberFormatException e) {

                System.out.println(
                        "Please enter a valid number."
                );
            }
        }
    }
    private void displayPatientCategories() {

    System.out.println("\nAVAILABLE PATIENT CATEGORIES:");

    PatientCategory[] categories =
            PatientCategory.values();

    for (int i = 0; i < categories.length; i++) {
        System.out.println(
                (i + 1) + ". " + categories[i]
        );
    }
}
}
