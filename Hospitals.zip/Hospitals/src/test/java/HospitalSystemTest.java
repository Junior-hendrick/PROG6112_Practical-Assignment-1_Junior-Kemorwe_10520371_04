/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class HospitalSystemTest {
    
    public HospitalSystemTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    private PatientManager patientManager;
    private HospitalWard ward;

    @BeforeEach
    public void setUp() {

        patientManager = new PatientManager();
        ward = new HospitalWard();
    }

    @Test
    public void testRegisterPatient() {

        Patient patient = new Patient(
                "P001",
                "John",
                "Smith",
                30,
                "Male",
                "Flu",
                PatientCategory.OUTPATIENT
        );

        boolean result =
                patientManager.registerPatient(patient);

        assertTrue(result);
        assertEquals(1,
                patientManager.getPatientCount());
    }

    @Test
    public void testSearchPatient() {

        Patient patient = new Patient(
                "P002",
                "Mary",
                "Jones",
                25,
                "Female",
                "Asthma",
                PatientCategory.EMERGENCY
        );

        patientManager.registerPatient(patient);

        Patient found =
                patientManager.searchPatient("P002");

        assertNotNull(found);
        assertEquals("Mary", found.getFirstName());
    }

    @Test
    public void testUpdatePatient() {

        Patient patient = new Patient(
                "P003",
                "Peter",
                "Brown",
                40,
                "Male",
                "Fever",
                PatientCategory.OUTPATIENT
        );

        patientManager.registerPatient(patient);

        boolean result =
                patientManager.updatePatient(
                        "P003",
                        "Michael",
                        "Brown",
                        41,
                        "Male",
                        "Flu",
                        PatientCategory.EMERGENCY
                );

        assertTrue(result);

        Patient updated =
                patientManager.searchPatient("P003");

        assertEquals("Michael",
                updated.getFirstName());

        assertEquals(41,
                updated.getAge());

        assertEquals(
                PatientCategory.EMERGENCY,
                updated.getCategory()
        );
    }

    @Test
    public void testDeletePatient() {

        Patient patient = new Patient(
                "P004",
                "Sarah",
                "White",
                29,
                "Female",
                "Cold",
                PatientCategory.OUTPATIENT
        );

        patientManager.registerPatient(patient);

        boolean result =
                patientManager.deletePatient("P004");

        assertTrue(result);
        assertNull(
                patientManager.searchPatient("P004")
        );
    }

    @Test
    public void testAllocateBed() {

        Inpatient patient =
                new Inpatient(
                        "P005",
                        "David",
                        "Williams",
                        50,
                        "Male",
                        "Injury",
                        "Ward 1",
                        "None"
                );

        patientManager.registerPatient(patient);

        boolean result =
                ward.allocateBed(patient, "B01");

        assertTrue(result);

        assertEquals(
                "B01",
                patient.getBedNumber()
        );

        assertEquals(
                1,
                ward.getOccupiedBedCount()
        );
    }

    @Test
    public void testReleaseBed() {

        Inpatient patient =
                new Inpatient(
                        "P006",
                        "Linda",
                        "Molefe",
                        45,
                        "Female",
                        "Infection",
                        "Ward 1",
                        "None"
                );

        ward.allocateBed(patient, "B02");

        boolean result =
                ward.releaseBed("B02");

        assertTrue(result);

        assertEquals(
                0,
                ward.getOccupiedBedCount()
        );
    }

    @Test
    public void testPreventDuplicatePatientIds() {

        Patient firstPatient =
                new Patient(
                        "P007",
                        "John",
                        "Smith",
                        30,
                        "Male",
                        "Flu",
                        PatientCategory.OUTPATIENT
                );

        Patient secondPatient =
                new Patient(
                        "P007",
                        "Peter",
                        "Jones",
                        40,
                        "Male",
                        "Cold",
                        PatientCategory.EMERGENCY
                );

        assertTrue(
                patientManager.registerPatient(firstPatient)
        );

        assertFalse(
                patientManager.registerPatient(secondPatient)
        );
    }

    @Test
    public void testPreventOccupiedBedAllocation() {

        Inpatient first =
                new Inpatient(
                        "P008",
                        "A",
                        "One",
                        20,
                        "Male",
                        "Flu",
                        "Ward 1",
                        "None"
                );

        Inpatient second =
                new Inpatient(
                        "P009",
                        "B",
                        "Two",
                        21,
                        "Female",
                        "Cold",
                        "Ward 1",
                        "None"
                );

        assertTrue(
                ward.allocateBed(first, "B03")
        );

        assertFalse(
                ward.allocateBed(second, "B03")
        );
    }

    @Test
    public void testPreventAllocationWhenAllBedsOccupied() {

        for (int i = 1; i <= 20; i++) {

            String id =
                    String.format("P%03d", i);

            Inpatient patient =
                    new Inpatient(
                            id,
                            "Patient",
                            "Test" + i,
                            20,
                            "Male",
                            "Condition",
                            "Ward 1",
                            "None"
                    );

            String bed =
                    String.format("B%02d", i);

            assertTrue(
                    ward.allocateBed(patient, bed)
            );
        }

        assertEquals(
                20,
                ward.getOccupiedBedCount()
        );

        Inpatient extraPatient =
                new Inpatient(
                        "P021",
                        "Extra",
                        "Patient",
                        25,
                        "Male",
                        "Condition",
                        "Ward 1",
                        "None"
                );

        assertFalse(
                ward.allocateBed(
                        extraPatient,
                        "B01"
                )
        );
    }

    @Test
    public void testSortBySurname() {

        patientManager.registerPatient(
                new Patient(
                        "P010",
                        "John",
                        "Zulu",
                        30,
                        "Male",
                        "Flu",
                        PatientCategory.OUTPATIENT
                )
        );

        patientManager.registerPatient(
                new Patient(
                        "P011",
                        "Mary",
                        "Adams",
                        25,
                        "Female",
                        "Cold",
                        PatientCategory.OUTPATIENT
                )
        );

        patientManager.sortBySurname();

        Patient[] patients =
                patientManager.getPatientArray();

        assertEquals(
                "Adams",
                patients[0].getLastName()
        );

        assertEquals(
                "Zulu",
                patients[1].getLastName()
        );
    }

    @Test
    public void testSortByPatientId() {

        patientManager.registerPatient(
                new Patient(
                        "P020",
                        "John",
                        "Smith",
                        30,
                        "Male",
                        "Flu",
                        PatientCategory.OUTPATIENT
                )
        );

        patientManager.registerPatient(
                new Patient(
                        "P012",
                        "Mary",
                        "Jones",
                        25,
                        "Female",
                        "Cold",
                        PatientCategory.OUTPATIENT
                )
        );

        patientManager.sortByPatientId();

        Patient[] patients =
                patientManager.getPatientArray();

        assertEquals(
                "P012",
                patients[0].getPatientId()
        );

        assertEquals(
                "P020",
                patients[1].getPatientId()
        );
    }
}
